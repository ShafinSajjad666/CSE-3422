import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import IsolationForest
import joblib
from django.shortcuts import render
from .models import Transaction

def load_dataset(request):
    try:
        # Query the historical transaction data from the MySQL database
        transactions = Transaction.objects.all()

        # Preprocess the data
        df = pd.DataFrame(list(transactions.values()))  # Convert queryset to DataFrame

        # Encode categorical variable: transaction type
        label_encoder = LabelEncoder()
        df['type_encoded'] = label_encoder.fit_transform(df['type'])

        # Scale numerical features
        scaler = StandardScaler()
        numerical_features = ['step', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']
        df[numerical_features] = scaler.fit_transform(df[numerical_features])

        # Select relevant features for training
        X_train = df[['step', 'type_encoded', 'amount', 'oldBalanceOrg', 'newBalanceOrig', 'oldBalanceDest', 'newBalanceDest']]

        # Train the Isolation Forest model
        isolation_forest_model = IsolationForest(contamination=0.01, random_state=42)
        isolation_forest_model.fit(X_train)

        # Decision function of the Isolation Forest model
        decision_function = isolation_forest_model.decision_function(X_train)

        # Save the trained Isolation Forest model to disk
        joblib.dump(isolation_forest_model, 'isolation_forest_model.pkl')

        # Display the loaded dataset for verification (remove this part later)
        return render(request, 'dataset_loaded.html', {'data': X_train.head().to_dict(orient='records')})
    
    except Exception as e:
        return render(request, 'error.html', {'error_message': str(e)})
