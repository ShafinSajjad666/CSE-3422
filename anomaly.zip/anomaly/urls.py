from django.urls import path, include

urlpatterns = [
    path('anomaly/', include('anomaly.urls')),  # Include URLs from the anomaly app
]
