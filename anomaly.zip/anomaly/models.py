from django.db import models

class Transaction(models.Model):
    step = models.IntegerField()
    type = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    nameOrig = models.CharField(max_length=100)
    oldBalanceOrg = models.DecimalField(max_digits=10, decimal_places=2)
    newBalanceOrig = models.DecimalField(max_digits=10, decimal_places=2)
    nameDest = models.CharField(max_length=100)
    oldBalanceDest = models.DecimalField(max_digits=10, decimal_places=2)
    newBalanceDest = models.DecimalField(max_digits=10, decimal_places=2)
    isFraud = models.BooleanField()
    isFlaggedFraud = models.BooleanField()

    def __str__(self):
        return f"Transaction {self.id}"
