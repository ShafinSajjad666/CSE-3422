from django.apps import AppConfig

class AnomalyConfig(AppConfig):
    name = 'anomaly'
