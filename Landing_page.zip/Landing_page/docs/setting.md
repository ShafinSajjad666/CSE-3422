# **Settings**
The settings module provides administrators with powerful tools for managing user accounts and permissions, ensuring secure access to the system's features and data. Additionally, users have the flexibility to customize their account settings, tailoring their experience to suit their preferences and needs.

## **User Management**

Admins have access to comprehensive user management controls, allowing them to efficiently manage user accounts and permissions within the system. Key features include:

- **Account Creation**: Admins can create new user accounts, assigning roles and permissions based on organizational requirements.
  
- **User Permissions**: Admins have the ability to grant or revoke permissions for individual users, ensuring that access to sensitive data and functionality is controlled and monitored.

## **User Account Settings**

Users have access to their account settings, allowing them to customize their experience and manage their personal information. Key features include:

- **KYC Form Updates**: Users can update certain information from their KYC (Know Your Customer) form, such as contact details or address, which will be securely updated in the system's database.
  
- **Password Management**: Users can change their passwords as needed to maintain account security.
  
- **Notification Preferences**: Users can configure their notification settings, choosing how and when they receive alerts and updates from the system.
  



