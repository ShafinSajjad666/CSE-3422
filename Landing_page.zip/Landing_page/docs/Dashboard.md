# **Dashboard**

## **Summary**

The dashboard provides a comprehensive summary of user profiles along with alerts regarding potential fraudulent activities.

## **Navigation**
Within this dashboard, users will find convenient links to various other sections. With just a single click, users can effortlessly navigate to their desired pages, enhancing accessibility and efficiency.

Navigate through different sections using the following links:

- [Data Anaalysis](data_analysis.md)
- [Data Management](data_management.md)
- [Reporting](reporting.md)
- [Setting](setting.md)
