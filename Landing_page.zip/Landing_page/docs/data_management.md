# **Data Management**
For data management, we will implement CRUD operations, facilitating the creation, reading, updating, and deletion of data to effectively manage and maintain data integrity.
## **Data Upload**

During the registration process, when users complete the KYC form, their information will be extracted from the form and securely stored in our database.

## **Data Storage**

For the data storage , there will be a database management system that can be access via localhost from XAMPP.

## **Data Access**

The data can be access from database. Also can perform update, delete and read operation on the database.