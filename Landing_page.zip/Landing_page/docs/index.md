# **Landing Page**

## **Secure Web Application for Transaction Data Management**

On this initial page, we'll prominently feature two key elements. Firstly, a graph illustrating fraud or anomaly detection data for a single day. This graph serves as a focal point, outlining the primary function of our application. Secondly, we'll provide options for login and registration. Existing users will be prompted to log in to access the site's features, while new users will be guided to complete the KYC form to register for our application.

## **Login/Registration**

To access our application, you need to login or register. We ensure secure access for authorized users through multi-factor authentication.

#### Login

To gain access to our application, users are required to input their credentials, including their username and password.

#### Registration

Individuals who do not yet possess an account can register here by completing the KYC form. This form entails providing a comprehensive array of personal, professional, and other pertinent information for registration purposes.


